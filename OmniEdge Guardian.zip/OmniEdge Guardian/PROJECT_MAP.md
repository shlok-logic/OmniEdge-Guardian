# OmniEdge Guardian - Project Map

## Project Vision
**North Star:** An omnipresent, zero-cloud Windows 11 ARM64 application optimized exclusively for Snapdragon-powered HP PCs. Prioritizing reliability over speed, leveraging the B.L.A.S.T. protocol and a 3-layer architecture.

## Core Features
1. **Local RAG:** Document and code search capabilities running entirely offline.
2. **Real-time PII Redaction:** Clipboard monitoring and redaction of Personally Identifiable Information.
3. **Offline Meeting Transcription:** Audio transcription using Whisper, running locally.

## Tech Stack & Constraints
- **Runtime:** ONNX Runtime with Qualcomm QNN Execution Provider.
- **Hardware Target:** Hexagon NPU (45 TOPS) on Snapdragon ARM64 to maintain <3W power budget and prevent thermal throttling.
- **Models:**
  - LLM: INT4 Llama-3.2-3B
  - Embedding: INT8 MiniLM
  - Audio: Whisper-Base
- **Frontend:** C# WinUI 3 (Native Windows UI styling)
- **Backend:** C++/Python (QNN backend)

## Data-First Schemas & Buffers
### JSON Data Schemas
#### Document Node (RAG)
```json
{
  "id": "string",
  "content": "string",
  "embedding": [/* float array */],
  "metadata": {
    "source": "string",
    "timestamp": "iso8601"
  }
}
```

#### PII Redaction Event
```json
{
  "eventId": "string",
  "originalLength": "number",
  "redactedEntities": ["string"],
  "timestamp": "iso8601"
}
```

#### Transcription Segment
```json
{
  "segmentId": "number",
  "start": "number",
  "end": "number",
  "text": "string",
  "speaker": "string"
}
```

### Memory Buffer Definitions (LPDDR5x Target)
- **RAG Context Buffer:** Pre-allocated tensor buffer for context window to minimize allocation overhead.
- **Audio Stream Buffer:** Rolling buffer for incoming microphone data, matching Whisper input requirements (16kHz, mono).
- **Clipboard Watcher Buffer:** Ephemeral string buffer for text interception and secure redaction processing.

## 3-Layer Architecture Overview
- **Layer 1 (Architecture):** Technical SOPs defining goals and edge cases for RAG and PII loops.
- **Layer 2 (Navigation):** Data routing and secure IPC mechanism between C# WinUI 3 frontend and C++/Python QNN backend.
- **Layer 3 (Tools):** Deterministic, testable modules (using `.tmp/` for intermediate file ops). Strict DRY principles applied throughout.
