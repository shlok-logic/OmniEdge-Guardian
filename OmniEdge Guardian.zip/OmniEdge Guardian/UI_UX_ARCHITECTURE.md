# OmniEdge Guardian - UI/UX Architecture

## Design System & Language
To align with the request for a beautiful, popular, and native UI, we will strictly follow the **Windows 11 Fluent Design System**. This ensures the application feels like a first-class citizen on Snapdragon ARM64 PCs.

### Core Visual Elements
1. **Materials:** We will use **Mica Backdrop** (`BackdropMaterial`) for the main application window. Mica samples the desktop wallpaper to create a beautiful, performance-friendly glassmorphism effect without draining the battery (crucial for our <3W power budget on the NPU).
2. **Typography:** **Segoe UI Variable**, which dynamically scales for legibility across different DPIs.
3. **Controls:** WinUI 3 modern controls (rounded corners, subtle animations).

## Application Layout (Main Window)
We will use a `NavigationView` pattern, which is the gold standard for multi-feature productivity apps on Windows.

### 1. Left Sidebar (NavigationView)
- **RAG Search:** A chat-based interface for querying local documents (Main default view).
- **PII Redaction Monitor:** A live dashboard showing intercepted clipboard events and redaction metrics.
- **Meeting Transcription:** An audio-recording interface with real-time text output from the local Whisper model.

### 2. Main Content Area (Frame)
A centralized frame that swaps pages based on the sidebar selection.

## XAML Scaffolding (MainWindow.xaml)

```xml
<Window
    x:Class="OmniEdgeGuardian.MainWindow"
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    xmlns:local="using:OmniEdgeGuardian"
    xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
    xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
    mc:Ignorable="d"
    SystemBackdrop="Mica">

    <Grid>
        <NavigationView x:Name="NavView" 
                        IsBackButtonVisible="Collapsed" 
                        ItemInvoked="NavView_ItemInvoked">
            
            <NavigationView.MenuItems>
                <NavigationViewItem Tag="RAG_Page" Content="RAG Search">
                    <NavigationViewItem.Icon>
                        <FontIcon Glyph="&#xE721;"/> <!-- Search Icon -->
                    </NavigationViewItem.Icon>
                </NavigationViewItem>

                <NavigationViewItem Tag="PII_Page" Content="PII Redaction Monitor">
                    <NavigationViewItem.Icon>
                        <FontIcon Glyph="&#xE753;"/> <!-- Shield Icon -->
                    </NavigationViewItem.Icon>
                </NavigationViewItem>

                <NavigationViewItem Tag="Whisper_Page" Content="Meeting Transcription">
                    <NavigationViewItem.Icon>
                        <FontIcon Glyph="&#xE720;"/> <!-- Mic Icon -->
                    </NavigationViewItem.Icon>
                </NavigationViewItem>
            </NavigationView.MenuItems>

            <Frame x:Name="ContentFrame" Padding="24">
                <Frame.ContentTransitions>
                    <TransitionCollection>
                        <NavigationThemeTransition/>
                    </TransitionCollection>
                </Frame.ContentTransitions>
            </Frame>
        </NavigationView>
    </Grid>
</Window>
```

## Next Steps for UI Integration
1. **Visual Studio:** You will need to open this project in Visual Studio 2022 with the ".NET desktop development" and "Windows App SDK" workloads installed. (I detected that the `dotnet` CLI is currently unavailable in this terminal session).
2. **Component Separation:** We will create `RAGPage.xaml`, `PIIPage.xaml`, and `WhisperPage.xaml` to keep the UI layer deterministic and DRY (Phase 3 - Layer 3 requirement).
