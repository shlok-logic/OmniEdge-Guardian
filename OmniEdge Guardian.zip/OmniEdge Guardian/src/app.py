import tkinter as tk
from tkinter import ttk, messagebox
import threading
import json
import urllib.request
import time
import math

API_BASE_URL = "http://127.0.0.1:5050"

# Premium Frosted Glassmorphism Theme (Purple/Aubergine & Neon Accents)
BG_WINDOW = "#170F24"      # Deep purple ambient backdrop
BG_SIDEBAR = "#1E1430"     # Glass sidebar
BG_CARD = "#2A1D45"        # Frosted glass card surface
BG_CARD_TRANSLUCENT = "#322353" # Lighter glass surface
BG_INPUT = "#201438"       # Deep input background
TEXT_MAIN = "#FFFFFF"      # Crisp bright white
TEXT_MUTED = "#9D8EC0"     # Muted purple text
ACCENT_PURPLE = "#8B5CF6"  # Bright Royal Violet
ACCENT_PINK = "#EC4899"    # Neon Magenta
ACCENT_TEAL = "#10B981"    # Emerald Mint
ACCENT_CYAN = "#06B6D4"    # Electric Cyan
BORDER_GLASS = "#44326C"   # Subtle luminous border

class OmniEdgeModernApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OmniEdge Guardian - NPU Security & Intelligence Suite")
        self.geometry("1180x780")
        self.minsize(1050, 680)
        self.configure(bg=BG_WINDOW)

        self.active_tab = "DASHBOARD"
        self.sidebar_nav_items = {}
        self.anim_step = 0
        self.is_running = True

        self.setup_ui()
        self.start_ambient_animation()

    def setup_ui(self):
        # ----------------- SIDEBAR (LEFT) -----------------
        self.sidebar = tk.Frame(self, bg=BG_SIDEBAR, width=250)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)

        # App Logo & Branding
        brand_box = tk.Frame(self.sidebar, bg=BG_SIDEBAR)
        brand_box.pack(fill=tk.X, padx=22, pady=(28, 20))

        logo_icon = tk.Label(brand_box, text="⚡", font=("Segoe UI Emoji", 20, "bold"), bg=ACCENT_PURPLE, fg="#FFFFFF", padx=8, pady=4)
        logo_icon.pack(side=tk.LEFT)

        brand_text_box = tk.Frame(brand_box, bg=BG_SIDEBAR)
        brand_text_box.pack(side=tk.LEFT, padx=12)

        tk.Label(brand_text_box, text="OmniEdge", font=("Segoe UI", 13, "bold"), bg=BG_SIDEBAR, fg=TEXT_MAIN).pack(anchor="w")
        tk.Label(brand_text_box, text="GUARDIAN AI", font=("Segoe UI", 8, "bold"), bg=BG_SIDEBAR, fg=ACCENT_PURPLE).pack(anchor="w")

        # Sidebar Separator
        tk.Frame(self.sidebar, bg=BORDER_GLASS, height=1).pack(fill=tk.X, padx=18, pady=(0, 20))

        # Nav Title
        tk.Label(self.sidebar, text="DASHBOARD", font=("Segoe UI", 8, "bold"), bg=BG_SIDEBAR, fg=TEXT_MUTED).pack(anchor="w", padx=26, pady=(0, 8))

        # Modern Nav Items (Matches the left menu of uploaded reference)
        self.create_nav_button("DASHBOARD", "📊  Overview", ACCENT_PURPLE)
        self.create_nav_button("RAG", "🔍  Local RAG Search", ACCENT_CYAN)
        self.create_nav_button("PII", "🔒  PII Shield", ACCENT_PINK)
        self.create_nav_button("WHISPER", "🎙️  Meeting Transcripts", ACCENT_TEAL)

        # Bottom Hardware Badge (NPU & Battery Profile)
        hw_widget = tk.Frame(self.sidebar, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        hw_widget.pack(side=tk.BOTTOM, fill=tk.X, padx=16, pady=20)

        hw_top = tk.Frame(hw_widget, bg=BG_CARD)
        hw_top.pack(fill=tk.X, padx=12, pady=(12, 4))

        self.npu_led = tk.Canvas(hw_top, width=10, height=10, bg=BG_CARD, highlightthickness=0)
        self.npu_led.pack(side=tk.LEFT)
        self.led_dot = self.npu_led.create_oval(1, 1, 9, 9, fill=ACCENT_TEAL, outline="")

        tk.Label(hw_top, text="Hexagon NPU Active", font=("Segoe UI", 9, "bold"), bg=BG_CARD, fg=TEXT_MAIN).pack(side=tk.LEFT, padx=8)
        
        tk.Label(hw_widget, text="45 TOPS • 1.8W Power Draw", font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_MUTED).pack(anchor="w", padx=12, pady=(0, 4))
        tk.Label(hw_widget, text="Zero-Cloud Air-Gapped", font=("Segoe UI", 8, "bold"), bg=BG_CARD, fg=ACCENT_TEAL).pack(anchor="w", padx=12, pady=(0, 12))

        # ----------------- MAIN GLASS CONTAINER (RIGHT) -----------------
        self.main_area = tk.Frame(self, bg=BG_WINDOW)
        self.main_area.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=25, pady=20)

        # Top Header Bar (With User Avatar & Search Box, like Reference)
        self.build_top_bar()

        # Content Pages
        self.pages_container = tk.Frame(self.main_area, bg=BG_WINDOW)
        self.pages_container.pack(fill=tk.BOTH, expand=True)

        self.pages = {}
        self.build_overview_page()
        self.build_rag_page()
        self.build_pii_page()
        self.build_whisper_page()

        self.switch_tab("DASHBOARD")

    def build_top_bar(self):
        top_bar = tk.Frame(self.main_area, bg=BG_WINDOW)
        top_bar.pack(fill=tk.X, pady=(0, 18))

        # Search Bar like the uploaded designs
        search_box = tk.Frame(top_bar, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        search_box.pack(side=tk.LEFT, ipady=6, ipadx=10)

        tk.Label(search_box, text="🔍", font=("Segoe UI", 10), bg=BG_CARD, fg=TEXT_MUTED).pack(side=tk.LEFT, padx=(4, 6))
        self.quick_search = tk.Entry(search_box, bg=BG_CARD, fg=TEXT_MAIN, font=("Segoe UI", 10), 
                                     relief=tk.FLAT, insertbackground=TEXT_MAIN, width=32)
        self.quick_search.pack(side=tk.LEFT)
        self.quick_search.insert(0, "Find security event or meeting...")

        # User Avatar & Filter Pill (Right)
        profile_frame = tk.Frame(top_bar, bg=BG_WINDOW)
        profile_frame.pack(side=tk.RIGHT)

        avatar_btn = tk.Label(profile_frame, text="👤 Sarah Lee", font=("Segoe UI", 10, "bold"), 
                              bg=BG_CARD, fg=TEXT_MAIN, padx=14, pady=8, highlightthickness=1, highlightbackground=BORDER_GLASS)
        avatar_btn.pack(side=tk.RIGHT, padx=8)

        status_pill = tk.Label(profile_frame, text="● Air-Gapped", font=("Segoe UI", 9, "bold"), 
                               bg="#183626", fg=ACCENT_TEAL, padx=12, pady=8)
        status_pill.pack(side=tk.RIGHT)

    def create_nav_button(self, key, label_text, accent_color):
        item_frame = tk.Frame(self.sidebar, bg=BG_SIDEBAR, cursor="hand2")
        item_frame.pack(fill=tk.X, padx=14, pady=4)

        indicator = tk.Frame(item_frame, bg=BG_SIDEBAR, width=4)
        indicator.pack(side=tk.LEFT, fill=tk.Y)

        lbl = tk.Label(item_frame, text=label_text, font=("Segoe UI", 10, "bold"), 
                       bg=BG_SIDEBAR, fg=TEXT_MUTED, padx=14, pady=10)
        lbl.pack(side=tk.LEFT, fill=tk.X, expand=True, anchor="w")

        def on_enter(e):
            if self.active_tab != key:
                item_frame.configure(bg=BG_CARD)
                lbl.configure(bg=BG_CARD, fg=TEXT_MAIN)

        def on_leave(e):
            if self.active_tab != key:
                item_frame.configure(bg=BG_SIDEBAR)
                lbl.configure(bg=BG_SIDEBAR, fg=TEXT_MUTED)

        def on_click(e):
            self.switch_tab(key)

        for w in (item_frame, lbl):
            w.bind("<Enter>", on_enter)
            w.bind("<Leave>", on_leave)
            w.bind("<Button-1>", on_click)

        self.sidebar_nav_items[key] = {
            "frame": item_frame,
            "indicator": indicator,
            "label": lbl,
            "accent": accent_color
        }

    def switch_tab(self, key):
        self.active_tab = key
        for k, v in self.sidebar_nav_items.items():
            if k == key:
                v["frame"].configure(bg=BG_CARD)
                v["indicator"].configure(bg=v["accent"])
                v["label"].configure(bg=BG_CARD, fg=TEXT_MAIN)
            else:
                v["frame"].configure(bg=BG_SIDEBAR)
                v["indicator"].configure(bg=BG_SIDEBAR)
                v["label"].configure(bg=BG_SIDEBAR, fg=TEXT_MUTED)

        for p in self.pages.values():
            p.pack_forget()

        self.pages[key].pack(fill=tk.BOTH, expand=True)

    # ------------------- 1. OVERVIEW DASHBOARD (MATCHES USER IMAGES) -------------------
    def build_overview_page(self):
        page = tk.Frame(self.pages_container, bg=BG_WINDOW)
        self.pages["DASHBOARD"] = page

        # Top Metric Stat Cards (Like Image 2)
        stats_grid = tk.Frame(page, bg=BG_WINDOW)
        stats_grid.pack(fill=tk.X, pady=(0, 16))

        # Card 1: Total Secure Queries
        self.create_stat_card(stats_grid, "TOTAL AI QUERIES", "352", "+12%", ACCENT_PURPLE, 0)
        # Card 2: PII Redactions Blocked
        self.create_stat_card(stats_grid, "PII ITEMS STRIPPED", "1,420", "+28%", ACCENT_PINK, 1)
        # Card 3: Meeting Audio Transcribed
        self.create_stat_card(stats_grid, "AUDIO RECORDED", "58h 12m", "NPU Active", ACCENT_TEAL, 2)

        # Middle Dashboard Layout (2 Columns: Animated Bar Chart & Circular Efficiency)
        mid_grid = tk.Frame(page, bg=BG_WINDOW)
        mid_grid.pack(fill=tk.BOTH, expand=True)

        # Left: Live Interactive Activity Chart (Like Bar Chart in Image 2)
        chart_card = tk.Frame(mid_grid, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        chart_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 12))

        tk.Label(chart_card, text="NPU Workload & Query Volume", font=("Segoe UI", 11, "bold"), bg=BG_CARD, fg=TEXT_MAIN).pack(anchor="w", padx=16, pady=(14, 4))
        tk.Label(chart_card, text="Real-time TOPS distribution per hour", font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_MUTED).pack(anchor="w", padx=16, pady=(0, 10))

        self.chart_canvas = tk.Canvas(chart_card, bg=BG_CARD, highlightthickness=0, height=180)
        self.chart_canvas.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 14))

        # Right: Efficiency Donut / Circle Widget (Like Image 1 & 2)
        right_panel = tk.Frame(mid_grid, bg=BG_CARD, width=320, highlightthickness=1, highlightbackground=BORDER_GLASS)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(4, 0))
        right_panel.pack_propagate(False)

        tk.Label(right_panel, text="Hardware Efficiency", font=("Segoe UI", 11, "bold"), bg=BG_CARD, fg=TEXT_MAIN).pack(anchor="w", padx=16, pady=(14, 4))
        
        self.donut_canvas = tk.Canvas(right_panel, width=150, height=150, bg=BG_CARD, highlightthickness=0)
        self.donut_canvas.pack(pady=10)

        tk.Label(right_panel, text="Hexagon NPU: 94% Battery Saved", font=("Segoe UI", 10, "bold"), bg=BG_CARD, fg=ACCENT_TEAL).pack()
        tk.Label(right_panel, text="Thermal Throttling: 0.0%", font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_MUTED).pack(pady=(2, 10))

        # Quick Launch RAG button inside dashboard
        quick_btn = tk.Button(right_panel, text="⚡ Open Local RAG Assistant", font=("Segoe UI", 9, "bold"), 
                              bg=ACCENT_PURPLE, fg="#FFFFFF", relief=tk.FLAT, cursor="hand2", pady=8, command=lambda: self.switch_tab("RAG"))
        quick_btn.pack(fill=tk.X, padx=16, pady=(10, 14))

    def create_stat_card(self, parent, subtitle, main_stat, badge_text, accent, col_idx):
        card = tk.Frame(parent, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=6 if col_idx == 1 else (0 if col_idx == 0 else 0))

        top_row = tk.Frame(card, bg=BG_CARD)
        top_row.pack(fill=tk.X, padx=16, pady=(14, 4))

        tk.Label(top_row, text=subtitle, font=("Segoe UI", 8, "bold"), bg=BG_CARD, fg=TEXT_MUTED).pack(side=tk.LEFT)
        tk.Label(top_row, text=badge_text, font=("Segoe UI", 8, "bold"), bg="#38265C", fg=accent, padx=8, pady=2).pack(side=tk.RIGHT)

        tk.Label(card, text=main_stat, font=("Segoe UI", 20, "bold"), bg=BG_CARD, fg=TEXT_MAIN).pack(anchor="w", padx=16, pady=(0, 12))

    # ------------------- 2. RAG CHAT PAGE -------------------
    def build_rag_page(self):
        page = tk.Frame(self.pages_container, bg=BG_WINDOW)
        self.pages["RAG"] = page

        chat_card = tk.Frame(page, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        chat_card.pack(fill=tk.BOTH, expand=True, pady=(0, 14))

        self.rag_chat = tk.Text(chat_card, bg=BG_CARD, fg=TEXT_MAIN, font=("Segoe UI", 10), 
                                relief=tk.FLAT, padx=18, pady=18, wrap=tk.WORD, state=tk.DISABLED)
        self.rag_chat.pack(fill=tk.BOTH, expand=True)

        self.append_chat(self.rag_chat, "🤖 OmniEdge Nexus AI:\nYour offline RAG copilot is ready on the Qualcomm Hexagon NPU.\nAsk anything about local documents, codebases, or meeting logs.\n\n")

        # Chat Input Area with Glass styling
        input_container = tk.Frame(page, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        input_container.pack(fill=tk.X)

        self.rag_input = tk.Entry(input_container, bg=BG_INPUT, fg=TEXT_MAIN, font=("Segoe UI", 11), 
                                  relief=tk.FLAT, insertbackground=ACCENT_CYAN)
        self.rag_input.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=12, padx=14, pady=8)
        self.rag_input.bind("<Return>", lambda e: self.send_rag_query())

        send_btn = tk.Button(input_container, text="⚡ Query NPU", font=("Segoe UI", 10, "bold"), 
                             bg=ACCENT_CYAN, fg="#0F172A", relief=tk.FLAT, cursor="hand2", padx=20, pady=8, command=self.send_rag_query)
        send_btn.pack(side=tk.RIGHT, padx=10, pady=8)

    def send_rag_query(self):
        prompt = self.rag_input.get().strip()
        if not prompt: return
        self.rag_input.delete(0, tk.END)
        self.append_chat(self.rag_chat, f"👤 You:\n{prompt}\n\n")
        
        # We don't append a "generating" line to avoid deletion bugs.
        # Instead, we just wait for the response.

        def task():
            try:
                data = json.dumps({"prompt": prompt}).encode("utf-8")
                req = urllib.request.Request(f"{API_BASE_URL}/rag/query", data=data, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req) as res:
                    ans = json.loads(res.read().decode()).get("response", "")
                    
                    # Schedule UI update on main thread
                    self.after(0, lambda: self.typewriter(self.rag_chat, f"🤖 Nexus AI (INT4 Llama-3.2):\n{ans}\n\n"))
            except Exception as e:
                # Schedule error message on main thread
                error_msg = f"⚠️ Connection Error: Ensure backend (main.py) is running! ({e})\n\n"
                self.after(0, lambda: self.append_chat(self.rag_chat, error_msg))
                
        threading.Thread(target=task, daemon=True).start()

    # ------------------- 3. PII REDACTION PAGE -------------------
    def build_pii_page(self):
        page = tk.Frame(self.pages_container, bg=BG_WINDOW)
        self.pages["PII"] = page

        # Input Card
        tk.Label(page, text="UNPROTECTED TEXT / CLIPBOARD", font=("Segoe UI", 8, "bold"), bg=BG_WINDOW, fg=TEXT_MUTED).pack(anchor="w", pady=(0, 4))
        in_card = tk.Frame(page, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        in_card.pack(fill=tk.BOTH, expand=True, pady=(0, 14))

        self.pii_in = tk.Text(in_card, bg=BG_CARD, fg=TEXT_MAIN, font=("Segoe UI", 10), relief=tk.FLAT, padx=14, pady=12)
        self.pii_in.pack(fill=tk.BOTH, expand=True)
        self.pii_in.insert(tk.END, "Secret log: Account admin with password 'AlphaSecurePass99' logged in.")

        redact_btn = tk.Button(page, text="🔒 Shield & Strip PII Data", font=("Segoe UI", 10, "bold"), 
                               bg=ACCENT_PINK, fg="#FFFFFF", relief=tk.FLAT, cursor="hand2", padx=22, pady=10, command=self.send_pii_redact)
        redact_btn.pack(anchor="w", pady=(0, 14))

        # Output Card
        tk.Label(page, text="CLEAN AIR-GAPPED OUTPUT", font=("Segoe UI", 8, "bold"), bg=BG_WINDOW, fg=TEXT_MUTED).pack(anchor="w", pady=(0, 4))
        out_card = tk.Frame(page, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        out_card.pack(fill=tk.BOTH, expand=True)

        self.pii_out = tk.Text(out_card, bg=BG_CARD, fg=ACCENT_TEAL, font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=14, pady=12)
        self.pii_out.pack(fill=tk.BOTH, expand=True)

    def send_pii_redact(self):
        text = self.pii_in.get("1.0", tk.END).strip()
        if not text: return
        
        def update_ui(redacted_text):
            self.pii_out.config(state=tk.NORMAL)
            self.pii_out.delete("1.0", tk.END)
            self.pii_out.insert(tk.END, redacted_text)
            self.pii_out.config(state=tk.DISABLED)

        def task():
            try:
                data = json.dumps({"clipboard_text": text}).encode("utf-8")
                req = urllib.request.Request(f"{API_BASE_URL}/pii/redact", data=data, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req) as res:
                    redacted = json.loads(res.read().decode()).get("redacted", "")
                    # Direct insert without typewriter for stability on this field
                    self.after(0, lambda: update_ui(redacted))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Backend error: Ensure main.py is running! ({e})"))
                
        threading.Thread(target=task, daemon=True).start()

    # ------------------- 4. WHISPER PAGE -------------------
    def build_whisper_page(self):
        page = tk.Frame(self.pages_container, bg=BG_WINDOW)
        self.pages["WHISPER"] = page

        # Dynamic Audio Visualizer
        vis_card = tk.Frame(page, bg=BG_CARD, height=80, highlightthickness=1, highlightbackground=BORDER_GLASS)
        vis_card.pack(fill=tk.X, pady=(0, 14))
        vis_card.pack_propagate(False)

        self.vis_canvas = tk.Canvas(vis_card, bg=BG_CARD, highlightthickness=0)
        self.vis_canvas.pack(fill=tk.BOTH, expand=True)

        # Output Card
        tk.Label(page, text="TRANSCRIPTION FEED", font=("Segoe UI", 8, "bold"), bg=BG_WINDOW, fg=TEXT_MUTED).pack(anchor="w", pady=(0, 4))
        out_card = tk.Frame(page, bg=BG_CARD, highlightthickness=1, highlightbackground=BORDER_GLASS)
        out_card.pack(fill=tk.BOTH, expand=True, pady=(0, 14))

        self.whisper_out = tk.Text(out_card, bg=BG_CARD, fg=TEXT_MAIN, font=("Segoe UI", 10), relief=tk.FLAT, padx=14, pady=14)
        self.whisper_out.pack(fill=tk.BOTH, expand=True)

        trans_btn = tk.Button(page, text="🎙️ Transcribe Audio Stream", font=("Segoe UI", 10, "bold"), 
                              bg=ACCENT_TEAL, fg="#0F172A", relief=tk.FLAT, cursor="hand2", padx=22, pady=10, command=self.send_whisper_transcribe)
        trans_btn.pack(anchor="w")

    def send_whisper_transcribe(self):
        def update_whisper(text_content):
            self.whisper_out.config(state=tk.NORMAL)
            self.whisper_out.insert(tk.END, text_content)
            self.whisper_out.config(state=tk.DISABLED)

        def task():
            try:
                data = json.dumps({"audio_data_hex": "415544494F"}).encode("utf-8")
                req = urllib.request.Request(f"{API_BASE_URL}/whisper/transcribe", data=data, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req) as res:
                    ans = json.loads(res.read().decode())
                    msg = f"[{ans.get('speaker', 'Speaker')}]: \"{ans.get('text', '')}\"\n\n"
                    self.after(0, lambda: update_whisper(msg))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", f"Backend error: Ensure main.py is running! ({e})"))
                
        threading.Thread(target=task, daemon=True).start()

    # ------------------- ANIMATIONS -------------------
    def start_ambient_animation(self):
        def update_frame():
            if not self.is_running: return
            self.anim_step += 0.08

            # 1. Animate Bar Chart (Overview tab)
            try:
                self.chart_canvas.delete("bar")
                cw = self.chart_canvas.winfo_width()
                ch = self.chart_canvas.winfo_height()
                if cw > 10:
                    bars = 22
                    bw = cw / bars
                    for i in range(bars):
                        bh = (math.sin(self.anim_step + i * 0.3) * 0.4 + 0.5) * (ch - 30) + 15
                        x0 = i * bw + 4
                        y0 = ch - bh
                        x1 = x0 + bw - 6
                        y1 = ch
                        color = ACCENT_PURPLE if i % 3 == 0 else "#4C3875"
                        if i == 14: color = ACCENT_PINK
                        self.chart_canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="", tags="bar")
            except Exception: pass

            # 2. Animate Donut Ring (Overview tab)
            try:
                self.donut_canvas.delete("all")
                # Outer circle track
                self.donut_canvas.create_oval(15, 15, 135, 135, outline="#38265C", width=12)
                # Animated Progress Arc
                extent = (math.sin(self.anim_step) * 15 + 280)
                self.donut_canvas.create_arc(15, 15, 135, 135, start=90, extent=-extent, outline=ACCENT_PURPLE, width=12, style="arc")
                self.donut_canvas.create_text(75, 75, text="45 TOPS", fill="#FFFFFF", font=("Segoe UI", 12, "bold"))
            except Exception: pass

            # 3. Animate Whisper Wave (if visible)
            try:
                if hasattr(self, "vis_canvas"):
                    self.vis_canvas.delete("wave")
                    vw = self.vis_canvas.winfo_width()
                    vh = self.vis_canvas.winfo_height()
                    if vw > 10:
                        nb = 35
                        bw = vw / nb
                        for i in range(nb):
                            bh = (math.sin(self.anim_step * 2 + i * 0.4) * 0.5 + 0.5) * (vh - 20) + 8
                            x0 = i * bw + 3
                            y0 = (vh - bh) / 2
                            x1 = x0 + bw - 5
                            y1 = y0 + bh
                            self.vis_canvas.create_rectangle(x0, y0, x1, y1, fill=ACCENT_TEAL, outline="", tags="wave")
            except Exception: pass

            self.after(50, update_frame)
        update_frame()

    def typewriter(self, widget, text, delay=0.01):
        for ch in text:
            widget.config(state=tk.NORMAL)
            widget.insert(tk.END, ch)
            widget.see(tk.END)
            time.sleep(delay)
        widget.config(state=tk.DISABLED)

    def append_chat(self, widget, text):
        widget.config(state=tk.NORMAL)
        widget.insert(tk.END, text)
        widget.see(tk.END)
        widget.config(state=tk.DISABLED)

    def remove_last_line(self, widget):
        widget.config(state=tk.NORMAL)
        widget.delete("end-2l", "end-1l")
        widget.config(state=tk.DISABLED)

if __name__ == "__main__":
    app = OmniEdgeModernApp()
    app.mainloop()
