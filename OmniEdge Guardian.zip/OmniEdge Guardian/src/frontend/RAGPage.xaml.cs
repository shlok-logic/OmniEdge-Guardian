using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using System;

namespace OmniEdgeGuardian
{
    public sealed partial class RAGPage : Page
    {
        private BackendClient _backendClient;

        public RAGPage()
        {
            this.InitializeComponent();
            _backendClient = new BackendClient();
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            await SubmitQuery();
        }

        private async void SearchBox_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                await SubmitQuery();
            }
        }

        private async System.Threading.Tasks.Task SubmitQuery()
        {
            string query = SearchBox.Text;
            if (string.IsNullOrWhiteSpace(query)) return;

            // Add User message to UI
            AddMessageToChat("You", query);
            SearchBox.Text = string.Empty;
            SearchBox.IsEnabled = false;

            try
            {
                // Call Python ONNX QNN Backend
                string response = await _backendClient.QueryRAGAsync(query);
                AddMessageToChat("Nexus AI", response);
            }
            catch (Exception ex)
            {
                AddMessageToChat("System Error", $"NPU Connection failed: {ex.Message}");
            }
            finally
            {
                SearchBox.IsEnabled = true;
                SearchBox.Focus(FocusState.Programmatic);
            }
        }

        private void AddMessageToChat(string sender, string message)
        {
            var textBlock = new TextBlock 
            { 
                Text = $"{sender}:\n{message}", 
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0,0,0,12)
            };
            ChatHistoryPanel.Children.Add(textBlock);
        }
    }
}
