using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OmniEdgeGuardian
{
    public class BackendClient
    {
        private readonly HttpClient _httpClient;
        private const string BaseUrl = "http://127.0.0.1:5050";

        public BackendClient()
        {
            _httpClient = new HttpClient();
        }

        public async Task<string> QueryRAGAsync(string prompt)
        {
            var payload = new { prompt = prompt };
            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync($"{BaseUrl}/rag/query", content);
            response.EnsureSuccessStatusCode();
            
            var responseString = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(responseString);
            return doc.RootElement.GetProperty("response").GetString();
        }

        public async Task<string> RedactPIIAsync(string clipboardText)
        {
            var payload = new { clipboard_text = clipboardText };
            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync($"{BaseUrl}/pii/redact", content);
            response.EnsureSuccessStatusCode();
            
            var responseString = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(responseString);
            return doc.RootElement.GetProperty("redacted").GetString();
        }
    }
}
